            set -ex
            echo 'DEBUG: Entered container, PWD='"/home/stephen/CR6Community-Marlin_TB"'
            yellow\ncd /code\necho 'DEBUG: Listing files in /home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft'\nls -l '/home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft'\necho 'DEBUG: Listing Marlin/ before copy'\nls -l Marlin/\necho 'DEBUG: Copying /home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft/Configuration*.h to Marlin/'\ncp /home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft/Configuration*.h Marlin/\necho 'DEBUG: Listing Marlin/ after copy'\nls -l Marlin/\necho 'Updating platformio.ini default_envs to: '\nsed -i 's/^default_envs = .*/default_envs = ''/' platformio.ini\necho 'Building firmware for platform: '\nplatformio run -e  --target clean\nplatformio run -e \necho 'Build completed successfully'\nEOF
            chmod +x "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/docker-build-script.sh"
            docker-compose -f "/home/stephen/CR6Community-Marlin_TB/tools/linux/build/docker/docker-compose.yml" run --rm -e PLATFORM_ENV="STM32F103RE_btt_USB" marlin bash "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/docker-build-script.sh" &> "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/platformio-build.log"

            BUILD_RESULT=0
            echo "[DEBUG] Docker build finished for btt-skr-cr6-with-stock-creality-tft with exit code "
            cat "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/platformio-build.log"
            if [  -ne 0 ]; then
                echo "ERROR: Build failed for btt-skr-cr6-with-stock-creality-tft. See /home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/platformio-build.log for details."
                return 1
            fi


            # Copy the most recent firmware*.bin file (handles timestamped names)
            local firmware_file=
            if [ -z "" ]; then
                echo "ERROR: No firmware binary found for btt-skr-cr6-with-stock-creality-tft. See /home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/platformio-build.log for build output."
                return 1
            fi

            cp "" "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/Firmware/Motherboard firmware/"
            echo "Firmware copied: "

            else
            echo "DRY RUN: Would build btt-skr-cr6-with-stock-creality-tft with platform STM32F103RE_btt_USB"
            fi

            # Copy configuration files
            cp "/home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft"/*.h "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/configs/" 2>/dev/null || true

            if [ "true" = true ]; then
                if [ "true" = true ] && [ "" != "true" ]; then
                    echo "Creating DWIN_SET.zip from touchscreen firmware..."
                    # Create ZIP file of DWIN_SET folder
                    local dwin_zip="/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/Firmware/Display Firmware/DWIN_SET.zip"
                    (cd "../CR-6-Touchscreen/src/DWIN" && zip -r "" "DWIN_SET")
                    mv "../CR-6-Touchscreen/src/DWIN/DWIN_SET.zip" ""
                    echo "Display firmware packaged: DWIN_SET.zip"
                elif [ "" = "true" ]; then
                    echo "DRY RUN: Would create DWIN_SET.zip from ../CR-6-Touchscreen/src/DWIN/DWIN_SET"
                else
                    echo "Creating URL shortcut for touchscreen firmware download..."
                    # Create URL shortcut file
                    cat > "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/Firmware/Display Firmware/CR-6-Touchscreen-Download.url" << EOF
            [InternetShortcut]
            URL=https://github.com/CR6Community/CR-6-touchscreen
            IconFile=https://github.com/favicon.ico
            IconIndex=0
        echo "Created download link: CR-6-Touchscreen-Download.url"
    fi
else
    # Configuration excludes touchscreen - copy the no-touchscreen.txt file to explain
    if [ -f "/home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft/no-touchscreen.txt" ] && [ "" != "true" ]; then
        cp "/home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft/no-touchscreen.txt" "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/Firmware/Display Firmware/"
        echo "Copied no-touchscreen.txt to Display Firmware folder"
    elif [ "" = "true" ]; then
        echo "DRY RUN: Would copy no-touchscreen.txt to Display Firmware folder"
    fi
    
    if [ "" != "true" ]; then
        echo "Configuration uses BTT TFT - no CR-6 touchscreen firmware needed"
    fi
    
    # Copy description if available
    if [ -f "/home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft/description.txt" ]; then
        cp "/home/stephen/CR6Community-Marlin_TB/config/btt-skr-cr6-with-stock-creality-tft/description.txt" "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/"
    else
        echo "Configuration: btt-skr-cr6-with-stock-creality-tft" > "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/description.txt"
        echo "Platform: STM32F103RE_btt_USB" >> "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/description.txt"
        echo "Built: 2025-08-17-01-44" >> "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/test_build-btt-skr-cr6-with-stock-creality-tft-2025-08-17-01-44/description.txt"
    fi
    
    if [ "" != "true" ]; then
        # Add repository URL shortcut at ZIP root level
        cat > "/home/stephen/CR6Community-Marlin_TB/.pio/build-output/CR6Community-Marlin-Repository.url" << EOF
[InternetShortcut]
URL=https://github.com/Thinkersbluff/CR6Community-Marlin_TB
IconFile=https://github.com/favicon.ico
IconIndex=0
